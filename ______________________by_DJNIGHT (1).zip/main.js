import { initializeApp } from './modules/app.js';

document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});