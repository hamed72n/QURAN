import { surahNames, surahAyahCounts, juzRanges } from './data.js';
import { validateAyahInput, formatTimestamp, getJuzNumber, getRemainingJuz, getRemainingSurah, showAppModal, showAppConfirm } from './utils.js';

let bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];

export function initializeApp() {
    populateSurahSelect();
    displayBookmarks();
    document.getElementById('clearBtn').addEventListener('click', clearAllData);
    document.getElementById('saveBtn').addEventListener('click', saveAyah);
}

function populateSurahSelect() {
    const surahNameSelect = document.getElementById('surahName');
    surahNames.forEach((name) => {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        surahNameSelect.appendChild(option);
    });
}

export function saveAyah() {
    const surahName = document.getElementById('surahName').value;
    const ayah = document.getElementById('ayah').value;

    if (!validateAyahInput(ayah, surahName)) {
        return;
    }

    if (surahName && ayah) {
        const surahNumber = surahNames.indexOf(surahName) + 1;
        const ayahNumber = parseInt(ayah);

        // التحقق من التكرار
        const exists = bookmarks.some(b => b.surahName === surahName && b.ayah === ayah);
        if (exists) {
            showAppModal('هذه الآية محفوظة مسبقًا');
            return;
        }

        const juz = getJuzNumber(surahNumber, ayahNumber);
        const timestamp = new Date().toISOString();

        bookmarks.unshift({ surahName, juz, ayah, timestamp });
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        displayBookmarks();

        document.getElementById('surahName').value = '';
        document.getElementById('ayah').value = '';
    } else {
        showAppModal('الرجاء إدخال اسم السورة ورقم الآية');
    }
}

export function displayBookmarks() {
    const tableBody = document.querySelector('#bookmarksTable tbody');
    tableBody.innerHTML = '';
    bookmarks.forEach((bookmark, index) => {
        const surahNumber = surahNames.indexOf(bookmark.surahName) + 1;
        const juzNumber = parseInt((bookmark.juz || '').match(/\d+/)?.[0] || 1);

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                ${bookmark.surahName}<br>
                <span class="remaining">${getRemainingSurah(surahNumber)}</span>
            </td>
            <td>
                ${bookmark.juz}<br>
                <span class="remaining">${getRemainingJuz(juzNumber)}</span>
            </td>
            <td>${bookmark.ayah}</td>
            <td class="timestamp">${formatTimestamp(bookmark.timestamp)}</td>
        `;

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'حذف';
        deleteBtn.style.cssText = 'margin:2px;padding:2px 6px;font-size:12px;background:#dc3545;color:#fff;border:none;border-radius:3px;cursor:pointer';
        deleteBtn.onclick = () => deleteBookmark(index);

        const editBtn = document.createElement('button');
        editBtn.textContent = 'تعديل';
        editBtn.style.cssText = 'margin:2px;padding:2px 6px;font-size:12px;background:#007bff;color:#fff;border:none;border-radius:3px;cursor:pointer';
        editBtn.onclick = () => editBookmark(index);

        const actionsTd = document.createElement('td');
        actionsTd.appendChild(deleteBtn);
        actionsTd.appendChild(document.createElement('br'));
        actionsTd.appendChild(editBtn);
        row.appendChild(actionsTd);

        tableBody.appendChild(row);
    });
}

export function editBookmark(index) {
    const bookmark = bookmarks[index];
    const newSurah = prompt(`تعديل السورة (أترك فارغًا للإبقاء على ${bookmark.surahName}):`, '');
    if (newSurah && !surahNames.includes(newSurah)) {
        showAppModal("يجب كتابة اسم السورة كما هي في قائمة السور حتى يستطيع البرنامج الارتكاز عليها في حساب السور المتبقية.");
        return;
    }
    const newAyahStr = prompt(`تعديل رقم الآية (أترك فارغًا للإبقاء على ${bookmark.ayah}):`, '');
    const newAyah = newAyahStr ? parseInt(newAyahStr) : bookmark.ayah;

    if (newSurah || newAyahStr) {
        const surahName = newSurah || bookmark.surahName;
        const ayah = newAyahStr ? parseInt(newAyahStr) : bookmark.ayah;
        if (!validateAyahInput(ayah, surahName)) return;
        const surahNumber = surahNames.indexOf(surahName) + 1;
        bookmarks[index] = {
            surahName,
            juz: getJuzNumber(surahNumber, ayah),
            ayah,
            timestamp: bookmark.timestamp
        };
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        displayBookmarks();
    }
}

function saveEdit(index, field, value) {
    const bookmark = bookmarks[index];
    if (field === 'surahName') {
        if (!surahNames.includes(value)) {
            showAppModal("يجب كتابة اسم السورة كما هي في قائمة السور حتى يستطيع البرنامج الارتكاز عليها في حساب السور المتبقية.");
            return;
        }

        const surahNumber = surahNames.indexOf(value) + 1;
        const maxAyah = surahAyahCounts[surahNumber - 1];
        if (parseInt(bookmark.ayah) > maxAyah) {
            showAppModal(`رقم الآية ${bookmark.ayah} غير صالح لسورة ${value}. يجب أن يكون بين 1 و ${maxAyah}`);
            return;
        }

        bookmark.surahName = value;
        bookmark.juz = getJuzNumber(surahNumber, parseInt(bookmark.ayah));
    } else if (field === 'ayah') {
        if (!validateAyahInput(value, bookmark.surahName)) {
            return;
        }

        const surahNumber = surahNames.indexOf(bookmark.surahName) + 1;
        const ayahNumber = parseInt(value);

        bookmark.ayah = value;
        bookmark.juz = getJuzNumber(surahNumber, ayahNumber);
    }
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    displayBookmarks();
}

export function deleteBookmark(index) {
    const bookmark = bookmarks[index];
    showAppConfirm(`هل أنت متأكد من حذف آية ${bookmark.ayah} من سورة ${bookmark.surahName}؟`, () => {
        bookmarks.splice(index, 1);
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        displayBookmarks();
    });
}

export function clearAllData() {
    if (!bookmarks.length) {
        showAppModal('لا توجد بيانات لمسحها');
        return;
    }
    showAppConfirm('هل أنت متأكد من مسح جميع البيانات؟ لا يمكن التراجع عن هذا الإجراء.', () => {
        bookmarks = [];
        localStorage.removeItem('bookmarks');
        displayBookmarks();
    });
}